// بيانات تسجيل الدخول
let correctUsername = "Mostafa";  // اسم المستخدم الصحيح
let correctPassword = "mo6540";  // كلمة المرور الصحيحة

const loginForm = document.getElementById('loginForm');
const loginPage = document.getElementById('loginPage');
const appPage = document.getElementById('appPage');
const errorMessage = document.getElementById('errorMessage');
const changeCredentialsForm = document.getElementById('changeCredentialsForm');
const newUsername = document.getElementById('newUsername');
const newPassword = document.getElementById('newPassword');
const changeErrorMessage = document.getElementById('changeErrorMessage');
const changeSuccessMessage = document.getElementById('changeSuccessMessage');
const customerForm = document.getElementById('customerForm');
const customerList = document.getElementById('customerList');
const customerCount = document.getElementById('customerCount');
const searchInput = document.getElementById('searchInput');
const settingsIcon = document.getElementById('settingsIcon');
const changeCredentials = document.getElementById('changeCredentials');
const logoutButton = document.getElementById('logoutButton');

let customers = [];

// التعامل مع تسجيل الدخول
loginForm.addEventListener('submit', (e) => {
  e.preventDefault();
  
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();
  
  // التحقق من اسم المستخدم وكلمة المرور
  if (username === correctUsername && password === correctPassword) {
    // إخفاء صفحة تسجيل الدخول وإظهار التطبيق
    loginPage.style.display = 'none';
    appPage.style.display = 'block';
  } else {
    // عرض رسالة الخطأ
    errorMessage.style.display = 'block';
  }
});

// تغيير اسم المستخدم وكلمة المرور
changeCredentialsForm.addEventListener('submit', (e) => {
  e.preventDefault();
  
  const newUser = newUsername.value.trim();
  const newPass = newPassword.value.trim();
  
  if (newUser && newPass) {
    // تحديث اسم المستخدم وكلمة المرور
    correctUsername = newUser;
    correctPassword = newPass;

    // عرض رسالة نجاح
    changeErrorMessage.style.display = 'none';
    changeSuccessMessage.style.display = 'block';

    // مسح الحقول بعد التغيير
    newUsername.value = '';
    newPassword.value = '';
  } else {
    // عرض رسالة خطأ في حال الإدخال غير صحيح
    changeErrorMessage.style.display = 'block';
    changeSuccessMessage.style.display = 'none';
  }
});

// إظهار نموذج تغيير البيانات عند النقر على أيقونة الإعدادات
settingsIcon.addEventListener('click', () => {
  changeCredentials.style.display = (changeCredentials.style.display === 'block') ? 'none' : 'block';
});

// تسجيل الخروج
logoutButton.addEventListener('click', () => {
  // إعادة إظهار صفحة تسجيل الدخول وإخفاء التطبيق
  appPage.style.display = 'none';
  loginPage.style.display = 'block';

  // إعادة تعيين الحقول
  document.getElementById('username').value = '';
  document.getElementById('password').value = '';
  errorMessage.style.display = 'none';
  changeCredentials.style.display = 'none';
});

// إضافة عميل
customerForm.addEventListener('submit', (e) => {
  e.preventDefault();

  const customerId = document.getElementById('customerId').value.trim();
  const name = document.getElementById('name').value.trim();
  const address = document.getElementById('address').value.trim();
  const phone = document.getElementById('phone').value.trim();

  const cabinet = document.getElementById('cabinet').value.trim();
  const box = document.getElementById('box').value.trim();
  const terminal = document.getElementById('terminal').value.trim();

  if (customerId && name && address && phone && cabinet && box && terminal) {
    const customer = { customerId, name, address, phone, cabinet, box, terminal };
    customers.push(customer);

    updateCustomerList();
    customerForm.reset();
  } else {
    alert("يرجى ملء جميع الحقول المطلوبة!");
  }
});

// البحث عن العملاء
searchInput.addEventListener('input', () => {
  const query = searchInput.value.toLowerCase();
  updateCustomerList(query);
});

function updateCustomerList(query = '') {
  customerList.innerHTML = '';

  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(query) ||
    customer.customerId.includes(query)
  );

  filteredCustomers.forEach(customer => {
    const li = document.createElement('li');
    li.textContent = `رقم العميل: ${customer.customerId}, الاسم: ${customer.name}, العنوان: ${customer.address}`;
    customerList.appendChild(li);
  });

  customerCount.textContent = filteredCustomers.length;
}
let currentUsername = "Mostafa";
let currentPassword = "password123";
